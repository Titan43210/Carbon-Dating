# Phami Pharma

## Live Demo

[https://phami-pharma.web.app/](https://phami-pharma.web.app/)

## Features

- It is a pharmacy website where you can buy medicines
- Here you can also know about out pharmacy service from here
- In this project , I have used React JS, Tailwind CSS and Firebase
- I have used Firebase Authentication
- I have used Private and Protected Route

## 💻 Developed By

![Developer PIC](https://avatars.githubusercontent.com/u/73340940?s=48&v=4)

## 🚀 Connect with me

[![Facebook Badge](https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white)](https://facebook.com/abtahinoorsm)
[![Instagram Badge](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://instagram.com/smabtahinoor)
[![Linkedin Badge](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://linkedin.com/in/smabtahinoor)
[![Github Badge](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/19smabtahinoor)
[![Mail Badge](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:abtahinorkabid@gmail.com)
[![Discord Badge](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://discord.gg/WJjCBB86PJ)
